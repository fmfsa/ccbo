STATUS: {'status': 'descriptive_only', 'expected_units': 720, 'valid_units': 630, 'inference_allowed': False, 'failure_count': 0} missing: 90

| scm | cond | method | n | final regret mean [95% t-CI] | cost-integrated regret mean [95% t-CI] | #seeds final>1 | median final |
|---|---|---|---|---|---|---|---|
| ParallelParent | A0 | CBO | 30 | 0.0004 [0.0001, 0.0007] | 6.3127 [4.6680, 7.9573] | 0 | 0.0001 |
| ParallelParent | A0 | QCBO | 30 | 0.0004 [0.0001, 0.0006] | 0.2595 [0.1818, 0.3372] | 0 | 0.0000 |
| ParallelParent | A0 | CBO-NP | 30 | 0.0006 [0.0003, 0.0009] | 27.0092 [20.9332, 33.0853] | 0 | 0.0002 |
| ParallelParent | A0 | BO-S | 30 | 0.0006 [0.0003, 0.0009] | 27.0092 [20.9332, 33.0853] | 0 | 0.0002 |
| ParallelParent | A0 | BO | 30 | 0.0190 [-0.0071, 0.0451] | 6.2297 [1.2275, 11.2319] | 0 | 0.0001 |
| ParallelParent | A1 | CBO | 30 | 4.2500 [4.2500, 4.2500] | 378.2500 [378.2500, 378.2501] | 30 | 4.2500 |
| ParallelParent | A1 | QCBO | 30 | 0.0004 [0.0001, 0.0006] | 0.2595 [0.1818, 0.3372] | 0 | 0.0000 |
| ParallelParent | A1 | CBO-NP | 30 | 4.2500 [4.2500, 4.2500] | 378.2501 [378.2500, 378.2503] | 30 | 4.2500 |
| FrontDoor | B0 | CBO | 30 | 0.0000 [0.0000, 0.0000] | 0.0212 [0.0012, 0.0411] | 0 | 0.0000 |
| FrontDoor | B0 | QCBO | 30 | 0.0034 [-0.0000, 0.0067] | 16.7892 [12.8221, 20.7562] | 0 | 0.0003 |
| FrontDoor | B0 | CBO-NP | 30 | 0.0007 [-0.0001, 0.0015] | 1.8234 [0.9435, 2.7034] | 0 | 0.0001 |
| FrontDoor | B0 | CBO-FALLBACK | 30 | 0.0010 [0.0002, 0.0017] | 1.7576 [0.9473, 2.5679] | 0 | 0.0001 |
| FrontDoor | B0 | BO-S | 30 | 0.0022 [0.0010, 0.0033] | 17.8208 [12.8167, 22.8250] | 0 | 0.0007 |
| FrontDoor | B0 | BO | 30 | 0.4706 [0.1501, 0.7910] | 52.8061 [26.3368, 79.2753] | 7 | 0.0027 |
| FrontDoor | B1 | CBO | 30 | 0.0010 [0.0002, 0.0017] | 1.7576 [0.9473, 2.5679] | 0 | 0.0001 |
| FrontDoor | B1 | QCBO | 30 | 0.0034 [-0.0000, 0.0067] | 16.7892 [12.8221, 20.7562] | 0 | 0.0003 |
| MediatedChain | C0 | CBO | 30 | 0.0000 [0.0000, 0.0000] | 0.0037 [-0.0001, 0.0075] | 0 | 0.0000 |
| MediatedChain | C0 | QCBO | 30 | 3.9600 [3.9600, 3.9600] | 431.6400 [431.6400, 431.6400] | 30 | 3.9600 |
| MediatedChain | C0 | HQCBO | 30 | 0.0000 [0.0000, 0.0000] | 44.6561 [39.3643, 49.9480] | 0 | 0.0000 |
| MediatedChain | C0 | BO-S | 30 | 0.0000 [0.0000, 0.0000] | 24.8488 [16.0160, 33.6816] | 0 | 0.0000 |
| MediatedChain | C0 | BO | 30 | 3.9600 [3.9600, 3.9600] | 431.6400 [431.6400, 431.6400] | 30 | 3.9600 |

PAIRED EFFECTS from analyzer: []
PAIRED EFFECTS recomputed (QCBO minus CBO; minimization; seeds 2000-2029; pointwise two-sided 95% Student t, df 29):
[
  {
    "scm": "ParallelParent",
    "cond": "A0",
    "contrast": "QCBO minus CBO; minimization",
    "metrics": [
      {
        "metric": "final_recommendation_regret",
        "n": 30,
        "mean_paired_difference": -4.546682984363956e-05,
        "ci95": [
          -0.00042689284346754755,
          0.0003359591837802684
        ]
      },
      {
        "metric": "cost_integrated_recommendation_regret",
        "n": 30,
        "mean_paired_difference": -6.053160895528437,
        "ci95": [
          -7.647504969030318,
          -4.458816822026557
        ]
      }
    ]
  },
  {
    "scm": "ParallelParent",
    "cond": "A1",
    "contrast": "QCBO minus CBO; minimization",
    "metrics": [
      {
        "metric": "final_recommendation_regret",
        "n": 30,
        "mean_paired_difference": -4.249645299181746,
        "ci95": [
          -4.249930797317313,
          -4.24935980104618
        ]
      },
      {
        "metric": "cost_integrated_recommendation_regret",
        "n": 30,
        "mean_paired_difference": -377.9905363937024,
        "ci95": [
          -378.06825910811176,
          -377.9128136792931
        ]
      }
    ]
  },
  {
    "scm": "FrontDoor",
    "cond": "B0",
    "contrast": "QCBO minus CBO; minimization",
    "metrics": [
      {
        "metric": "final_recommendation_regret",
        "n": 30,
        "mean_paired_difference": 0.003340673674514168,
        "ci95": [
          -3.6641798333277974e-05,
          0.006717989147361615
        ]
      },
      {
        "metric": "cost_integrated_recommendation_regret",
        "n": 30,
        "mean_paired_difference": 16.767976440190374,
        "ci95": [
          12.80275900768615,
          20.7331938726946
        ]
      }
    ]
  },
  {
    "scm": "FrontDoor",
    "cond": "B1",
    "contrast": "QCBO minus CBO; minimization",
    "metrics": [
      {
        "metric": "final_recommendation_regret",
        "n": 30,
        "mean_paired_difference": 0.002407730363152975,
        "ci95": [
          -0.0011702659695902312,
          0.005985726695896181
        ]
      },
      {
        "metric": "cost_integrated_recommendation_regret",
        "n": 30,
        "mean_paired_difference": 15.031569928391653,
        "ci95": [
          10.97647606913244,
          19.086663787650863
        ]
      }
    ]
  },
  {
    "scm": "MediatedChain",
    "cond": "C0",
    "contrast": "QCBO minus CBO; minimization",
    "metrics": [
      {
        "metric": "final_recommendation_regret",
        "n": 30,
        "mean_paired_difference": 3.9599999545977984,
        "ci95": [
          3.959999926013189,
          3.9599999831824078
        ]
      },
      {
        "metric": "cost_integrated_recommendation_regret",
        "n": 30,
        "mean_paired_difference": 431.6363194862681,
        "ci95": [
          431.6324891014619,
          431.64014987107436
        ]
      }
    ]
  }
]

protected_checks: total 60 | exact_equal true: 60 | required: 60
  QCBO A1 vs baseline: 30/30 exact_equal
  QCBO B1 vs baseline: 30/30 exact_equal
failures: []
missing_units (first 5): ['FrontDoor-B0-CEO-seed2000', 'FrontDoor-B0-CEO-seed2001', 'FrontDoor-B0-CEO-seed2002', 'FrontDoor-B0-CEO-seed2003', 'FrontDoor-B0-CEO-seed2004'] ... methods: ['CEO']
